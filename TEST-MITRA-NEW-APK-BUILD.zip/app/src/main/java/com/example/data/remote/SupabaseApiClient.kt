package com.example.data.remote

import android.content.Context
import com.example.data.SupabaseConfig
import com.example.model.ActiveSession
import com.example.model.AdminInfo
import com.example.model.ExamType
import com.example.model.NotificationItem
import com.example.model.Profile
import com.example.model.Question
import com.example.model.StudentInfo
import com.example.model.Test
import com.example.model.TestAnswer
import com.example.model.TestAttempt
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class SupabaseApiClient(private val context: Context) {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun getBaseUrl(): String {
        return SupabaseConfig.getUrl(context).trimEnd('/')
    }

    private fun getAnonKey(): String {
        return SupabaseConfig.getAnonKey(context)
    }

    private fun buildRequest(url: String, method: String = "GET", jsonBody: String? = null): Request {
        val builder = Request.Builder()
            .url(url)
            .addHeader("apikey", getAnonKey())
            .addHeader("Authorization", "Bearer ${getAnonKey()}")
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "return=representation")

        when (method.uppercase()) {
            "POST" -> builder.post((jsonBody ?: "{}").toRequestBody(jsonMediaType))
            "PATCH" -> builder.patch((jsonBody ?: "{}").toRequestBody(jsonMediaType))
            "DELETE" -> builder.delete()
            else -> builder.get()
        }

        return builder.build()
    }

    private suspend fun executeRaw(request: Request): String = withContext(Dispatchers.IO) {
        val baseUrl = getBaseUrl()
        if (baseUrl.isBlank()) {
            throw Exception("Supabase Configuration is missing. Please configure SUPABASE_URL and SUPABASE_ANON_KEY.")
        }
        try {
            val response = okHttpClient.newCall(request).execute()
            val bodyString = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                throw Exception("Supabase Error (${response.code}): $bodyString")
            }
            bodyString
        } catch (e: java.io.IOException) {
            throw Exception("Internet connection તપાસો અને ફરી પ્રયાસ કરો.")
        }
    }

    // --- PROFILES ---
    suspend fun getProfileByMobile(mobileNumber: String): Profile? {
        val url = "${getBaseUrl()}/rest/v1/profiles?mobile_number=eq.$mobileNumber&select=*"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, Profile::class.java)
        val adapter = moshi.adapter<List<Profile>>(listType)
        return adapter.fromJson(json)?.firstOrNull()
    }

    suspend fun getProfileById(profileId: String): Profile? {
        val url = "${getBaseUrl()}/rest/v1/profiles?id=eq.$profileId&select=*"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, Profile::class.java)
        val adapter = moshi.adapter<List<Profile>>(listType)
        return adapter.fromJson(json)?.firstOrNull()
    }

    suspend fun createProfile(profile: Profile): Profile {
        val url = "${getBaseUrl()}/rest/v1/profiles"
        val adapter = moshi.adapter(Profile::class.java)
        val body = adapter.toJson(profile)
        val json = executeRaw(buildRequest(url, "POST", body))
        val listType = Types.newParameterizedType(List::class.java, Profile::class.java)
        val listAdapter = moshi.adapter<List<Profile>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: profile
    }

    suspend fun getAllProfiles(): List<Profile> {
        val url = "${getBaseUrl()}/rest/v1/profiles?select=*"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, Profile::class.java)
        val adapter = moshi.adapter<List<Profile>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    suspend fun updateProfileStatus(profileId: String, isActive: Boolean) {
        val url = "${getBaseUrl()}/rest/v1/profiles?id=eq.$profileId"
        val body = "{\"is_active\": $isActive}"
        executeRaw(buildRequest(url, "PATCH", body))
    }

    suspend fun deleteProfile(profileId: String) {
        val url = "${getBaseUrl()}/rest/v1/profiles?id=eq.$profileId"
        executeRaw(buildRequest(url, "DELETE"))
    }

    // --- EXAM TYPES ---
    suspend fun getExamTypes(): List<ExamType> {
        val url = "${getBaseUrl()}/rest/v1/exam_types?select=*&is_active=eq.true"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, ExamType::class.java)
        val adapter = moshi.adapter<List<ExamType>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    // --- ADMINS ---
    suspend fun createAdmin(adminInfo: AdminInfo): AdminInfo {
        val url = "${getBaseUrl()}/rest/v1/admins"
        val adapter = moshi.adapter(AdminInfo::class.java)
        val body = adapter.toJson(adminInfo)
        val json = executeRaw(buildRequest(url, "POST", body))
        val listType = Types.newParameterizedType(List::class.java, AdminInfo::class.java)
        val listAdapter = moshi.adapter<List<AdminInfo>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: adminInfo
    }

    suspend fun getAdminByProfileId(profileId: String): AdminInfo? {
        val url = "${getBaseUrl()}/rest/v1/admins?profile_id=eq.$profileId&select=*"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, AdminInfo::class.java)
        val adapter = moshi.adapter<List<AdminInfo>>(listType)
        return adapter.fromJson(json)?.firstOrNull()
    }

    suspend fun getAllAdmins(): List<AdminInfo> {
        val url = "${getBaseUrl()}/rest/v1/admins?select=*"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, AdminInfo::class.java)
        val adapter = moshi.adapter<List<AdminInfo>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    // --- STUDENTS ---
    suspend fun createStudent(studentInfo: StudentInfo): StudentInfo {
        val url = "${getBaseUrl()}/rest/v1/students"
        val adapter = moshi.adapter(StudentInfo::class.java)
        val body = adapter.toJson(studentInfo)
        val json = executeRaw(buildRequest(url, "POST", body))
        val listType = Types.newParameterizedType(List::class.java, StudentInfo::class.java)
        val listAdapter = moshi.adapter<List<StudentInfo>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: studentInfo
    }

    suspend fun getStudentByProfileId(profileId: String): StudentInfo? {
        val url = "${getBaseUrl()}/rest/v1/students?profile_id=eq.$profileId&select=*"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, StudentInfo::class.java)
        val adapter = moshi.adapter<List<StudentInfo>>(listType)
        return adapter.fromJson(json)?.firstOrNull()
    }

    suspend fun getStudentsByExamType(examTypeId: String?): List<StudentInfo> {
        val url = if (examTypeId.isNull_or_blank()) {
            "${getBaseUrl()}/rest/v1/students?select=*"
        } else {
            "${getBaseUrl()}/rest/v1/students?exam_type_id=eq.$examTypeId&select=*"
        }
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, StudentInfo::class.java)
        val adapter = moshi.adapter<List<StudentInfo>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    // --- TESTS ---
    suspend fun getTests(examTypeId: String?, statusFilter: String? = null): List<Test> {
        var url = "${getBaseUrl()}/rest/v1/tests?select=*"
        if (!examTypeId.isNull_or_blank()) {
            url += "&exam_type_id=eq.$examTypeId"
        }
        if (!statusFilter.isNull_or_blank()) {
            url += "&status=eq.$statusFilter"
        }
        url += "&order=created_at.desc"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, Test::class.java)
        val adapter = moshi.adapter<List<Test>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    suspend fun createTest(test: Test): Test {
        val url = "${getBaseUrl()}/rest/v1/tests"
        val adapter = moshi.adapter(Test::class.java)
        val body = adapter.toJson(test)
        val json = executeRaw(buildRequest(url, "POST", body))
        val listType = Types.newParameterizedType(List::class.java, Test::class.java)
        val listAdapter = moshi.adapter<List<Test>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: test
    }

    suspend fun updateTestStatus(testId: String, status: String) {
        val url = "${getBaseUrl()}/rest/v1/tests?id=eq.$testId"
        val body = "{\"status\": \"$status\"}"
        executeRaw(buildRequest(url, "PATCH", body))
    }

    suspend fun deleteTest(testId: String) {
        val url = "${getBaseUrl()}/rest/v1/tests?id=eq.$testId"
        executeRaw(buildRequest(url, "DELETE"))
    }

    // --- QUESTIONS ---
    suspend fun getQuestionsByTestId(testId: String): List<Question> {
        val url = "${getBaseUrl()}/rest/v1/questions?test_id=eq.$testId&select=*&order=question_order.asc"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, Question::class.java)
        val adapter = moshi.adapter<List<Question>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    suspend fun createQuestion(question: Question): Question {
        val url = "${getBaseUrl()}/rest/v1/questions"
        val adapter = moshi.adapter(Question::class.java)
        val body = adapter.toJson(question)
        val json = executeRaw(buildRequest(url, "POST", body))
        val listType = Types.newParameterizedType(List::class.java, Question::class.java)
        val listAdapter = moshi.adapter<List<Question>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: question
    }

    suspend fun deleteQuestion(questionId: String) {
        val url = "${getBaseUrl()}/rest/v1/questions?id=eq.$questionId"
        executeRaw(buildRequest(url, "DELETE"))
    }

    // --- NOTIFICATIONS ---
    suspend fun getNotifications(examTypeId: String?): List<NotificationItem> {
        var url = "${getBaseUrl()}/rest/v1/notifications?select=*&is_active=eq.true"
        if (!examTypeId.isNull_or_blank()) {
            url += "&exam_type_id=eq.$examTypeId"
        }
        url += "&order=created_at.desc"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, NotificationItem::class.java)
        val adapter = moshi.adapter<List<NotificationItem>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    suspend fun createNotification(notification: NotificationItem): NotificationItem {
        val url = "${getBaseUrl()}/rest/v1/notifications"
        val adapter = moshi.adapter(NotificationItem::class.java)
        val body = adapter.toJson(notification)
        val json = executeRaw(buildRequest(url, "POST", body))
        val listType = Types.newParameterizedType(List::class.java, NotificationItem::class.java)
        val listAdapter = moshi.adapter<List<NotificationItem>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: notification
    }

    suspend fun deleteNotification(notificationId: String) {
        val url = "${getBaseUrl()}/rest/v1/notifications?id=eq.$notificationId"
        executeRaw(buildRequest(url, "DELETE"))
    }

    // --- TEST ATTEMPTS & ANSWERS ---
    suspend fun createTestAttempt(attempt: TestAttempt): TestAttempt {
        val url = "${getBaseUrl()}/rest/v1/test_attempts"
        val adapter = moshi.adapter(TestAttempt::class.java)
        val body = adapter.toJson(attempt)
        val json = executeRaw(buildRequest(url, "POST", body))
        val listType = Types.newParameterizedType(List::class.java, TestAttempt::class.java)
        val listAdapter = moshi.adapter<List<TestAttempt>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: attempt
    }

    suspend fun updateTestAttempt(attempt: TestAttempt): TestAttempt {
        val url = "${getBaseUrl()}/rest/v1/test_attempts?id=eq.${attempt.id}"
        val adapter = moshi.adapter(TestAttempt::class.java)
        val body = adapter.toJson(attempt)
        val json = executeRaw(buildRequest(url, "PATCH", body))
        val listType = Types.newParameterizedType(List::class.java, TestAttempt::class.java)
        val listAdapter = moshi.adapter<List<TestAttempt>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: attempt
    }

    suspend fun getTestAttemptsByStudent(studentId: String): List<TestAttempt> {
        val url = "${getBaseUrl()}/rest/v1/test_attempts?student_id=eq.$studentId&select=*&order=started_at.desc"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, TestAttempt::class.java)
        val adapter = moshi.adapter<List<TestAttempt>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    suspend fun getAllTestAttempts(): List<TestAttempt> {
        val url = "${getBaseUrl()}/rest/v1/test_attempts?select=*&order=started_at.desc"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, TestAttempt::class.java)
        val adapter = moshi.adapter<List<TestAttempt>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    suspend fun createTestAnswers(answers: List<TestAnswer>) {
        if (answers.isEmpty()) return
        val url = "${getBaseUrl()}/rest/v1/test_answers"
        val listType = Types.newParameterizedType(List::class.java, TestAnswer::class.java)
        val adapter = moshi.adapter<List<TestAnswer>>(listType)
        val body = adapter.toJson(answers)
        executeRaw(buildRequest(url, "POST", body))
    }

    suspend fun getTestAnswersForAttempt(attemptId: String): List<TestAnswer> {
        val url = "${getBaseUrl()}/rest/v1/test_answers?attempt_id=eq.$attemptId&select=*"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, TestAnswer::class.java)
        val adapter = moshi.adapter<List<TestAnswer>>(listType)
        return adapter.fromJson(json) ?: emptyList()
    }

    // --- ACTIVE SESSIONS (One Account - One Active Device) ---
    suspend fun registerActiveSession(session: ActiveSession): ActiveSession {
        // Deactivate previous active sessions for this user first
        val invalidateUrl = "${getBaseUrl()}/rest/v1/active_sessions?user_id=eq.${session.userId}"
        executeRaw(buildRequest(invalidateUrl, "PATCH", "{\"is_active\": false}"))

        // Create new active session
        val createUrl = "${getBaseUrl()}/rest/v1/active_sessions"
        val adapter = moshi.adapter(ActiveSession::class.java)
        val body = adapter.toJson(session)
        val json = executeRaw(buildRequest(createUrl, "POST", body))
        val listType = Types.newParameterizedType(List::class.java, ActiveSession::class.java)
        val listAdapter = moshi.adapter<List<ActiveSession>>(listType)
        return listAdapter.fromJson(json)?.firstOrNull() ?: session
    }

    suspend fun getActiveSessionForUser(userId: String): ActiveSession? {
        val url = "${getBaseUrl()}/rest/v1/active_sessions?user_id=eq.$userId&is_active=eq.true&select=*&order=created_at.desc"
        val json = executeRaw(buildRequest(url))
        val listType = Types.newParameterizedType(List::class.java, ActiveSession::class.java)
        val adapter = moshi.adapter<List<ActiveSession>>(listType)
        return adapter.fromJson(json)?.firstOrNull()
    }

    suspend fun invalidateActiveSession(userId: String) {
        val url = "${getBaseUrl()}/rest/v1/active_sessions?user_id=eq.$userId"
        executeRaw(buildRequest(url, "PATCH", "{\"is_active\": false}"))
    }

    private fun String?.isNull_or_blank(): Boolean {
        return this == null || this.trim().isEmpty()
    }
}
